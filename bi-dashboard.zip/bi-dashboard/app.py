"""
Business Intelligence & Sales KPI Dashboard
--------------------------------------------
Interactive Python analytics dashboard providing executive insights into
sales trends, product margins, and customer cohort behavior.

Run:
    pip install -r requirements.txt
    streamlit run app.py
"""

import pandas as pd
import plotly.express as px
import streamlit as st

from data_generator import load_data

st.set_page_config(page_title="Sales KPI Dashboard", layout="wide", page_icon="📊")


# ---------------------------------------------------------------------------
# Data loading (cached so filters don't regenerate the dataset every rerun)
# ---------------------------------------------------------------------------
@st.cache_data
def get_data() -> pd.DataFrame:
    return load_data(days=180)


df = get_data()

# ---------------------------------------------------------------------------
# Sidebar filters
# ---------------------------------------------------------------------------
st.sidebar.header("Filters")

min_date, max_date = df["date"].min(), df["date"].max()
date_range = st.sidebar.date_input(
    "Date range", value=(min_date, max_date), min_value=min_date, max_value=max_date
)

regions = st.sidebar.multiselect("Region", options=sorted(df["region"].unique()), default=None)
categories = st.sidebar.multiselect(
    "Category", options=sorted(df["category"].unique()), default=None
)

filtered = df.copy()
if isinstance(date_range, tuple) and len(date_range) == 2:
    start, end = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
    filtered = filtered[(filtered["date"] >= start) & (filtered["date"] <= end)]
if regions:
    filtered = filtered[filtered["region"].isin(regions)]
if categories:
    filtered = filtered[filtered["category"].isin(categories)]

if filtered.empty:
    st.warning("No data matches the selected filters.")
    st.stop()

# ---------------------------------------------------------------------------
# Header + KPI cards
# ---------------------------------------------------------------------------
st.title("📊 Business Intelligence & Sales KPI Dashboard")
st.caption("Executive view of revenue, margin, and customer behavior")

total_revenue = filtered["revenue"].sum()
total_margin = filtered["margin"].sum()
avg_margin_pct = filtered["margin_pct"].mean()
n_orders = filtered["order_id"].nunique()
n_customers = filtered["customer_id"].nunique()
aov = total_revenue / n_orders if n_orders else 0

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Total Revenue", f"₹{total_revenue:,.0f}")
k2.metric("Total Margin", f"₹{total_margin:,.0f}")
k3.metric("Avg Margin %", f"{avg_margin_pct:.1%}")
k4.metric("Orders", f"{n_orders:,}")
k5.metric("Avg Order Value", f"₹{aov:,.0f}")

st.divider()

# ---------------------------------------------------------------------------
# Row 1: revenue trend + revenue by category
# ---------------------------------------------------------------------------
c1, c2 = st.columns((2, 1))

with c1:
    daily = filtered.groupby("date", as_index=False).agg(revenue=("revenue", "sum"))
    daily["revenue_7d_avg"] = daily["revenue"].rolling(7, min_periods=1).mean()
    fig = px.line(
        daily,
        x="date",
        y=["revenue", "revenue_7d_avg"],
        title="Daily Revenue (with 7-day rolling average)",
        labels={"value": "Revenue (₹)", "date": "Date", "variable": ""},
    )
    fig.update_layout(legend=dict(orientation="h", y=1.1))
    st.plotly_chart(fig, use_container_width=True)

with c2:
    by_cat = filtered.groupby("category", as_index=False).agg(revenue=("revenue", "sum"))
    fig = px.pie(by_cat, names="category", values="revenue", title="Revenue by Category", hole=0.45)
    st.plotly_chart(fig, use_container_width=True)

# ---------------------------------------------------------------------------
# Row 2: product margins + region comparison
# ---------------------------------------------------------------------------
c3, c4 = st.columns(2)

with c3:
    by_product = (
        filtered.groupby("product", as_index=False)
        .agg(revenue=("revenue", "sum"), margin_pct=("margin_pct", "mean"))
        .sort_values("revenue", ascending=True)
    )
    fig = px.bar(
        by_product,
        x="revenue",
        y="product",
        orientation="h",
        color="margin_pct",
        color_continuous_scale="RdYlGn",
        title="Revenue & Margin % by Product",
        labels={"revenue": "Revenue (₹)", "product": "", "margin_pct": "Margin %"},
    )
    st.plotly_chart(fig, use_container_width=True)

with c4:
    by_region = filtered.groupby(["region", "category"], as_index=False).agg(
        revenue=("revenue", "sum")
    )
    fig = px.bar(
        by_region,
        x="region",
        y="revenue",
        color="category",
        title="Revenue by Region & Category",
        labels={"revenue": "Revenue (₹)", "region": ""},
    )
    st.plotly_chart(fig, use_container_width=True)

# ---------------------------------------------------------------------------
# Row 3: customer cohort behavior
# ---------------------------------------------------------------------------
st.subheader("Customer Cohort Behavior")

cohort = filtered.groupby("customer_id").agg(
    first_order=("date", "min"), orders=("order_id", "nunique"), revenue=("revenue", "sum")
)
cohort["cohort_month"] = cohort["first_order"].dt.to_period("M").astype(str)

c5, c6 = st.columns(2)
with c5:
    cohort_summary = cohort.groupby("cohort_month", as_index=False).agg(
        customers=("orders", "count"), avg_orders=("orders", "mean"), avg_revenue=("revenue", "mean")
    )
    fig = px.bar(
        cohort_summary,
        x="cohort_month",
        y="customers",
        title="New Customers by Acquisition Month",
        labels={"cohort_month": "Cohort", "customers": "Customers"},
    )
    st.plotly_chart(fig, use_container_width=True)

with c6:
    repeat_rate = (cohort["orders"] > 1).mean()
    st.metric("Repeat Purchase Rate", f"{repeat_rate:.1%}")
    fig = px.histogram(
        cohort,
        x="orders",
        nbins=cohort["orders"].max() or 1,
        title="Orders per Customer (distribution)",
        labels={"orders": "Orders", "count": "Customers"},
    )
    st.plotly_chart(fig, use_container_width=True)

# ---------------------------------------------------------------------------
# Raw data (optional)
# ---------------------------------------------------------------------------
with st.expander("View filtered raw data"):
    st.dataframe(filtered.sort_values("date", ascending=False), use_container_width=True)
