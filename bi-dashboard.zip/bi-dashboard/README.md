# Business Intelligence & Sales KPI Dashboard

Interactive Python analytics dashboard (Streamlit + Pandas + Plotly) providing
executive insights into sales trends, product margins, and customer cohort
behavior.

## Structure
```
app.py               Streamlit dashboard (KPIs, charts, filters)
data_generator.py     Synthetic sales dataset generator (swap for a real source)
requirements.txt
```

## Setup & run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Features
- **KPI cards**: total revenue, total margin, average margin %, order count, average order value
- **Trend view**: daily revenue with 7-day rolling average
- **Category & product mix**: revenue by category (pie) and revenue/margin % by product (bar)
- **Regional comparison**: revenue by region, broken down by category
- **Cohort analysis**: new customers by acquisition month, repeat purchase rate, orders-per-customer distribution
- **Sidebar filters**: date range, region, category — all charts and KPIs recompute live
- **Raw data drill-down**: expandable table of the filtered dataset

## Using real data
Replace `load_data()` in `data_generator.py` with a query against your
warehouse/CSV/API. Keep the same column contract (`date`, `customer_id`,
`product`, `category`, `region`, `quantity`, `unit_price`, `revenue`, `cost`,
`margin`, `margin_pct`) and `app.py` needs no changes.
