"""
Generates a realistic synthetic sales dataset so the dashboard runs
out-of-the-box with no external data source required.
Replace `load_data()` with a real query (warehouse, CSV export, API) in
production — the rest of app.py only depends on the column contract below.
"""

from datetime import datetime, timedelta

import numpy as np
import pandas as pd

PRODUCTS = [
    ("Aurora Desk Lamp", "Home", 1499, 0.42),
    ("Nimbus Backpack", "Accessories", 2999, 0.38),
    ("Pulse Wireless Mouse", "Electronics", 1299, 0.55),
    ("Quartz Water Bottle", "Home", 799, 0.60),
    ("Halcyon Headphones", "Electronics", 4999, 0.35),
    ("Ember Yoga Mat", "Fitness", 1899, 0.48),
    ("Solace Office Chair", "Home", 8999, 0.30),
    ("Drift Notebook Set", "Stationery", 499, 0.65),
]

REGIONS = ["North", "South", "East", "West"]


def load_data(days: int = 180, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    start = datetime.today() - timedelta(days=days)

    rows = []
    order_id = 10000
    for day_offset in range(days):
        date = start + timedelta(days=day_offset)
        # weekday seasonality: weekends slightly slower for a B2B-leaning mix
        base_orders = 18 if date.weekday() < 5 else 11
        n_orders = rng.poisson(base_orders)

        for _ in range(n_orders):
            name, category, price, margin_pct = PRODUCTS[rng.integers(len(PRODUCTS))]
            qty = int(rng.integers(1, 4))
            region = REGIONS[rng.integers(len(REGIONS))]
            # small random price jitter (promotions/discounts)
            unit_price = round(price * rng.uniform(0.85, 1.05), 2)
            revenue = round(unit_price * qty, 2)
            cost = round(revenue * (1 - margin_pct) * rng.uniform(0.9, 1.1), 2)
            customer_id = f"CUST-{rng.integers(1, 900):04d}"

            rows.append(
                {
                    "order_id": order_id,
                    "date": date,
                    "customer_id": customer_id,
                    "product": name,
                    "category": category,
                    "region": region,
                    "quantity": qty,
                    "unit_price": unit_price,
                    "revenue": revenue,
                    "cost": cost,
                    "margin": round(revenue - cost, 2),
                }
            )
            order_id += 1

    df = pd.DataFrame(rows)
    df["margin_pct"] = (df["margin"] / df["revenue"]).round(4)
    return df
